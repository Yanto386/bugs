require("./all/module.js")
const { color } = require('./all/function')
const { version } = require("./package.json")
//========== Setting Owner ==========//
global.owner = "6281915843156"
global.owner2 = "6281915843156"
global.namaowner = "Lax"
global.botname = "Shadow Botz"
//======== Setting Bot & Link ========//
global.namabot = "KleeMD - Cpanel" 
global.namabot2 = "KleeMD - BotWa"
global.foother = "© KleeMD - FlowFalcon"
global.idsaluran = false
global.linkgc = 'https://www.flowfalcon.xyz/'
global.linksaluran = "https://whatsapp.com/channel/0029VasjrIh3gvWXKzWncf2P"
global.linkyt = 'https://www.flowfalcon.xyz/'
global.linktele = 'https://www.flowfalcon.xyz/'
global.packname = "KleeMD Official"
global.author = "FlowFalcon"

//========== Setting Event ==========//
global.welcome = true
global.autoread = true
global.anticall = false
global.owneroff = false


//========== Setting Panel Server  1==========//
global.domain = ""
global.apikey = ""
global.capikey = ""
//========== Setting Panel Server  2==========//
global.domain2 = ""
global.apikey2 = ""
global.capikey2 = ""
//======== egg & loc biasanya sama jadi gausah ========//
global.egg = "15"
global.loc = "1"

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Done Bang ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})